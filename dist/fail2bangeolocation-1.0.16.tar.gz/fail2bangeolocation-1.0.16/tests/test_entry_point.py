from src.fail2bangeolocation.fail2bangeolocation import main

if __name__ == '__main__':
    main()
